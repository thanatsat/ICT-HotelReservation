import 'package:flutter/material.dart';
import 'package:thanat_s_application1/presentation/hotel_screen/hotel_screen.dart';

class AppRoutes {
  static const String hotelScreen = '/hotel_screen';

  static Map<String, WidgetBuilder> routes = {
    hotelScreen: (context) => HotelScreen()
  };
}
