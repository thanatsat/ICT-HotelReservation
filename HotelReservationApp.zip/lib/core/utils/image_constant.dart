class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Hotel images
  static String imgImage1 = '$imagePath/img_image_1.png';

  static String imgFrame2 = '$imagePath/img_frame_2.png';

  static String imgFrame17 = '$imagePath/img_frame_17.png';

  static String imgFrame247x47 = '$imagePath/img_frame_2_47x47.png';

  static String imgImage3 = '$imagePath/img_image_3.png';

  static String imgRectangle5 = '$imagePath/img_rectangle_5.png';

  static String imgImage385x85 = '$imagePath/img_image_3_85x85.png';

  static String imgRectangle4 = '$imagePath/img_rectangle_4.png';

  static String imgImage31 = '$imagePath/img_image_3_1.png';

  static String imgRectangle485x84 = '$imagePath/img_rectangle_4_85x84.png';

  static String imgImage32 = '$imagePath/img_image_3_2.png';

  static String imgRectangle3 = '$imagePath/img_rectangle_3.png';

  static String imgFrame253x54 = '$imagePath/img_frame_2_53x54.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
